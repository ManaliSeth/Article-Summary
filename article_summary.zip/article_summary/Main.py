from project import app

app.run(port=7812)

