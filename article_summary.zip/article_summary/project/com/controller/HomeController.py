from project import app
from flask import render_template,session
from project.com.vo.LoginVO import LoginVO
from project.com.dao.LoginDAO import LoginDAO
from project.com.dao.UserDAO import UserDAO


@app.route('/')
def loadIndex():
    userDAO = UserDAO()
    userCountDict = userDAO.getUserCount()
    print(userCountDict)
    summaryCountDict = userDAO.getSummaryCount()
    print(summaryCountDict)
    return render_template('userSummary/index2.html', userCountDict=userCountDict, summaryCountDict=summaryCountDict)


@app.route('/loadHome')
def loadHome():
    userDAO = UserDAO()
    userCountDict = userDAO.getUserCount()
    print(userCountDict)
    summaryCountDict = userDAO.getSummaryCount()
    print(summaryCountDict)
    return render_template('userSummary/index2.html', userCountDict=userCountDict, summaryCountDict=summaryCountDict)


@app.route('/loadUser')
def loadUser():
    userDAO = UserDAO()
    userCountDict = userDAO.getUserCount()
    print(userCountDict)
    summaryCountDict = userDAO.getSummaryCount()
    print(summaryCountDict)
    return render_template('userSummary/index.html', userCountDict=userCountDict, summaryCountDict=summaryCountDict)


@app.route('/loadAdmin')
def loadAdmin():

    loginDAO = LoginDAO()

    summaryCountDict = loginDAO.getSummaryCount()
    print("summary count=", summaryCountDict)

    userCountDict = loginDAO.getUserCount()
    print('user count=', userCountDict)

    userSummaryCountDict = loginDAO.getUserSummaryCount()
    print('user summary count=', userSummaryCountDict)

    userComplainCountDict = loginDAO.getUserComplainCount()
    print('user complain count=', userComplainCountDict)

    userFeedbackCountDict = loginDAO.getUserFeedbackCount()
    print('user feedback count=', userFeedbackCountDict)

    return render_template('adminSummary/index.html',data=summaryCountDict,usercount=userCountDict,usersummary=userSummaryCountDict,usercomplain=userComplainCountDict,userfeedback=userFeedbackCountDict)

