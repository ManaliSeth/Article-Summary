from project import app
from flask import render_template, request, redirect, url_for, session
from project.com.vo.SummaryVO import SummaryVO
from project.com.dao.SummaryDAO import SummaryDAO
from werkzeug.utils import secure_filename
import os
import datetime

from nltk.corpus import stopwords
from nltk.cluster.util import cosine_distance
import numpy as np
import networkx as nx

@app.route('/userLoadSummary')
def userLoadSummary():
    return render_template('userSummary/addFile.html')


@app.route('/userAddFile',methods=['POST'])
def userAddFile():

    UPLOAD_FOLDER = 'project/static/adminresources/dataset'
    UPLOAD_FOLDER2 = 'project/static/adminresources/summary_dataset'

    app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
    app.config['UPLOAD_FOLDER2'] = UPLOAD_FOLDER2

    file = request.files['file']
    print(file)

    filename = secure_filename(file.filename)
    print(filename)
    filename2 = secure_filename('summary_'+file.filename)
    print(filename2)

    filepath = os.path.join(app.config['UPLOAD_FOLDER'])
    print(filepath)
    filepath2 = os.path.join(app.config['UPLOAD_FOLDER2'])
    print(filepath2)

    file.save(os.path.join(app.config['UPLOAD_FOLDER'],filename))
    file.save(os.path.join(app.config['UPLOAD_FOLDER2'],filename2))

    summary_articleType = request.form['summary_articleType']
    summary_articleFormat = request.form['summary_articleFormat']

    summaryVO = SummaryVO()

    summary_LoginId = session['loginId']
    print(summary_LoginId)

    currentDT = datetime.datetime.now()

    summaryDate = currentDT.strftime("%Y/%m/%d")

    def read_article(file_name):
        file = open(file_name, "r")
        filedata = file.readlines()
        article = filedata[0].split(". ")
        print(article)
        sentences = []

        for sentence in article:
            # print(sentence)
            sentences.append(sentence.replace("[^a-zA-Z]", " ").split(" "))
            print(sentences)
        sentences.pop()

        return sentences

    def sentence_similarity(sent1, sent2, stopwords=None):
        if stopwords is None:
            stopwords = []

        sent1 = [w.lower() for w in sent1]
        sent2 = [w.lower() for w in sent2]

        all_words = list(set(sent1 + sent2))
        print("all_words:", all_words)

        vector1 = [0] * len(all_words)
        vector2 = [0] * len(all_words)
        print("Vector1:", vector1)
        print("Vector2:", vector2)

        print(sent1)
        # build the vector for the first sentence
        for w in sent1:
            if w in stopwords:
                continue
            vector1[all_words.index(w)] += 1
            print("v1:", vector1)

        print(sent2)
        # build the vector for the second sentence
        for w in sent2:
            if w in stopwords:
                continue
            vector2[all_words.index(w)] += 1
            # print("v2:", vector2)

        return 1 - cosine_distance(vector1, vector2)

    def build_similarity_matrix(sentences, stop_words):
        # Create an empty similarity matrix
        similarity_matrix = np.zeros((len(sentences), len(sentences)))

        for idx1 in range(len(sentences)):
            for idx2 in range(len(sentences)):
                if idx1 == idx2:  # ignore if both are same sentences
                    continue
                similarity_matrix[idx1][idx2] = sentence_similarity(sentences[idx1], sentences[idx2], stop_words)

        return similarity_matrix

    def generate_summary(file_name, top_n=5):
        stop_words = stopwords.words('english')
        summarize_text = []

        # Step 1 - Read text anc split it
        sentences = read_article(file_name)

        # Step 2 - Generate Similary Martix across sentences
        sentence_similarity_martix = build_similarity_matrix(sentences, stop_words)

        # Step 3 - Rank sentences in similarity martix
        sentence_similarity_graph = nx.from_numpy_array(sentence_similarity_martix)
        scores = nx.pagerank(sentence_similarity_graph)

        # Step 4 - Sort the rank and pick top sentences
        ranked_sentence = sorted(((scores[i], s) for i, s in enumerate(sentences)), reverse=True)
        print("Indexes of top ranked_sentence order are ", ranked_sentence)

        for i in range(top_n):
            summarize_text.append(" ".join(ranked_sentence[i][1]))

        # Step 5 - Offcourse, output the summarize texr
        print("Summarize Text: \n", ". ".join(summarize_text))
        return summarize_text

    fileToSummarize = "C:/Users/DELL/PycharmProjects/article_summary/project/static/adminresources/dataset/"+filename
    print(fileToSummarize)

    # let's begin
    summary = generate_summary(fileToSummarize, 2)
    print(summary)
    summary_generated=''
    for i in summary:
        summary_generated =summary_generated + i + ". "
    print(summary_generated)

    file = "C:/Users/DELL/PycharmProjects/article_summary/project/static/adminresources/summary_dataset/"+filename2
    openfile = open(file,'w+')
    openfile.write(summary_generated)
    openfile.close()

    summaryVO.datasetname = filename
    summaryVO.datasetpath = filepath
    summaryVO.summary_datasetname = filename2
    summaryVO.summary_datasetpath = filepath2
    summaryVO.summary_LoginId = summary_LoginId
    summaryVO.summaryDate = summaryDate
    summaryVO.summary_articleType = summary_articleType
    summaryVO.summary_articleFormat = summary_articleFormat


    summaryDAO = SummaryDAO()

    summaryDAO.userAddSummary(summaryVO)

    return redirect(url_for('userLoadSummary'))

@app.route('/userViewUserSummary')
def userViewUserSummary():
    if 'loginId' in session and session['loginRole'] == "user":

        loginId = session['loginId']

        print("loginId=", loginId)

        summaryVO = SummaryVO()

        summaryVO.summary_LoginId = loginId

        summaryDAO = SummaryDAO()

        fileDict= summaryDAO.userViewUserSummary(summaryVO)

        print(fileDict)

        return render_template('userSummary/viewUserSummary.html',fileDict=fileDict)

    else:

        return redirect(url_for('loadUser'))


@app.route('/adminViewUserSummary')
def adminViewUserSummary():
    if 'loginId' in session and session['loginRole'] == "admin":

        loginId = session['loginId']

        print("loginId=", loginId)

        summaryVO = SummaryVO()

        summaryDAO = SummaryDAO()

        fileDict = summaryDAO.adminViewUserSummary()

        print(fileDict)

        return render_template('adminSummary/viewUserSummary.html', fileDict=fileDict)

    else:

        return redirect(url_for('loadAdmin'))


