from project import app
from flask import render_template, request, session
from project.com.vo.LoginVO import LoginVO
from project.com.dao.LoginDAO import LoginDAO
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText


@app.route('/contactUs', methods=['POST'])
def contactUs():
    loginEmail = request.form['loginEmail']

    loginVO = LoginVO()
    loginVO.loginEmail = loginEmail
    print(loginVO.loginEmail)

    session['loginEmail'] = loginEmail
    print(session['loginEmail'])

    message = "Thank you for connecting with us. We will try to revert you back as soon as possible."

    session['message'] = message

    print("message=" + message)

    sender = "pythondemodonotreply@gmail.com"

    receiver = loginEmail

    msg = MIMEMultipart()

    msg['FROM'] = sender

    msg['TO'] = receiver

    msg['Subject'] = "Message received"

    msg.attach(MIMEText(message, 'plain'))

    server = smtplib.SMTP('smtp.gmail.com', 587)

    server.starttls()

    server.login(sender, "qazwsxedcrfvtgb1234567890!")

    text = msg.as_string()

    server.sendmail(sender, receiver, text)

    server.quit()

    return render_template('userSummary/contactUs.html')


@app.route('/loginContactUs', methods=['POST'])
def loginContactUs():
    loginEmail = request.form['loginEmail']

    loginVO = LoginVO()
    loginVO.loginEmail = loginEmail
    print(loginVO.loginEmail)

    session['loginEmail'] = loginEmail
    print(session['loginEmail'])

    loginDAO = LoginDAO()
    loginDict = loginDAO.checkLoginEmail(loginVO)

    print("loginDict=", loginDict)

    if len(loginDict) == 0:
        return render_template('userSummary/loginContactUs.html', msg="Incorrect EmailID")

    else:

        message = "Thank you for connecting with us. We will try to revert you back as soon as possible."

        session['message'] = message

        print("message=" + message)

        sender = "pythondemodonotreply@gmail.com"

        receiver = loginEmail

        msg = MIMEMultipart()

        msg['FROM'] = sender

        msg['TO'] = receiver

        msg['Subject'] = "Message received"

        msg.attach(MIMEText(message, 'plain'))

        server = smtplib.SMTP('smtp.gmail.com', 587)

        server.starttls()

        server.login(sender, "qazwsxedcrfvtgb1234567890!")

        text = msg.as_string()

        server.sendmail(sender, receiver, text)

        server.quit()

        return render_template('userSummary/loginContactUs.html')
