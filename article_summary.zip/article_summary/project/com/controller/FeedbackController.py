from project import app
from flask import render_template,request,session,redirect,url_for
from project.com.vo.FeedbackVO import FeedbackVO
from project.com.dao.FeedbackDAO import FeedbackDAO
import datetime


@app.route('/userLoadFeedback')
def userLoadFeedback():
    return render_template('userSummary/addFeedback.html')


@app.route('/userAddFeedback',methods=['POST'])
def userAddFeedback():

    feedbackRating = request.form['feedbackRating']
    feedbackDescription = request.form['feedbackDescription']

    feedbackVO = FeedbackVO()

    feedbackFrom_LoginId = session['loginId']
    print(feedbackFrom_LoginId)

    currentDT = datetime.datetime.now()

    feedbackDate = currentDT.strftime("%Y/%m/%d")

    feedbackVO.feedbackRating = feedbackRating
    feedbackVO.feedbackDescription = feedbackDescription
    feedbackVO.feedbackFrom_LoginId = feedbackFrom_LoginId
    feedbackVO.feedbackDate = feedbackDate

    feedbackDAO = FeedbackDAO()

    feedbackDAO.userAddFeedback(feedbackVO)

    return redirect(url_for('userLoadFeedback'))

@app.route('/userViewUserFeedback')
def userViewUserFeedback():
    if 'loginId' in session and session['loginRole'] == "user":

        loginId = session['loginId']

        print("loginId=", loginId)

        feedbackVO = FeedbackVO()

        feedbackVO.feedbackFrom_LoginId = loginId

        print(feedbackVO.feedbackFrom_LoginId)

        feedbackDAO = FeedbackDAO()

        feedbackDict = feedbackDAO.userViewUserFeedback(feedbackVO)

        print(feedbackDict)

        return render_template('userSummary/viewFeedback.html', feedbackDict=feedbackDict)

    else:

        return redirect(url_for('loadUser'))

@app.route('/adminViewUserFeedback')
def adminViewUserFeedback():
    if 'loginId' in session and session['loginRole'] == "admin":

        loginId = session['loginId']

        print("loginId=", loginId)

        feedbackVO = FeedbackVO()

        feedbackDAO = FeedbackDAO()

        feedbackDict = feedbackDAO.adminViewUserFeedback(feedbackVO)

        return render_template('adminSummary/viewUserFeedback.html', feedbackDict=feedbackDict)

    else:

        return redirect(url_for('loadAdmin'))


