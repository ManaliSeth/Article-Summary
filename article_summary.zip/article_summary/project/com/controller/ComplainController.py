from project import app
from flask import render_template, request, redirect, url_for, session
from project.com.vo.ComplainVO import ComplainVO
from project.com.dao.ComplainDAO import ComplainDAO
from werkzeug.utils import secure_filename
import os
import datetime


@app.route('/userLoadComplain')
def userLoadComplain():

    return render_template('userSummary/addComplain.html')


@app.route('/userAddComplain',methods=['POST'])
def userAddComplain():

    UPLOAD_FOLDER = 'project/static/adminresources/dataset'

    app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

    complainSubject = request.form['complainSubject']

    complainDescription = request.form['complainDescription']

    file = request.files['file']
    print(file)

    filename = secure_filename(file.filename)
    print(filename)

    filepath = os.path.join(app.config['UPLOAD_FOLDER'])
    print(filepath)

    file.save(os.path.join(app.config['UPLOAD_FOLDER'],filename))

    complainVO = ComplainVO()

    complainFrom_LoginId = session['loginId']
    print(complainFrom_LoginId)

    currentDT = datetime.datetime.now()

    complainDate = currentDT.strftime("%Y/%m/%d")
    complainTime = currentDT.strftime("%H:%M:%S")


    complainVO.complainSubject = complainSubject
    complainVO.complainDescription = complainDescription
    complainVO.datasetname = filename
    complainVO.datasetpath = filepath
    complainVO.complainFrom_LoginId = complainFrom_LoginId
    complainVO.complainDate = complainDate
    complainVO.complainTime = complainTime
    complainVO.complainStatus = "pending"


    complainDAO = ComplainDAO()

    complainDAO.userAddComplain(complainVO)

    return redirect(url_for('userLoadComplain'))

@app.route('/userViewUserComplain')
def userViewUserComplain():
    if 'loginId' in session and session['loginRole'] == "user":

        loginId = session['loginId']

        print("loginId=", loginId)

        complainVO = ComplainVO()

        complainVO.complainFrom_LoginId = loginId

        complainDAO = ComplainDAO()

        complainDict = complainDAO.userViewUserComplain(complainVO)

        print(complainDict)

        return render_template('userSummary/viewUserComplain.html',complainDict=complainDict)

    else:

        return redirect(url_for('loadUser'))


@app.route('/adminViewUserComplain')
def adminViewUserComplain():
    if 'loginId' in session and session['loginRole'] == "admin":

        loginId = session['loginId']

        print("loginId=", loginId)

        complainDAO = ComplainDAO()

        complainDict = complainDAO.adminViewUserComplain()

        print(complainDict)

        return render_template('adminSummary/viewUserComplain.html', complainDict=complainDict)

    else:

        return redirect(url_for('loadAdmin'))


@app.route('/adminLoadReplyUserComplain')
def adminLoadReplyUserComplain():

    complainId = request.args.get('complainId')
    complainVO = ComplainVO()
    complainVO.complainId = complainId
    print(complainId)
    print(complainVO.complainId)
    complainDAO = ComplainDAO()
    complainDict = complainDAO.getUserComplaintDetails(complainVO)
    print(complainDict)
    return render_template('adminSummary/replyUserComplain.html',complainDict=complainDict)


@app.route('/adminReplyUserComplain',methods = ['POST'])
def adminReplyUserComplain():
    if 'loginId' in session and session['loginRole'] == "admin":

        loginId = session['loginId']

        print("loginId=", loginId)

        complainId = request.form['complainId']
        print("complainId=",complainId)

        replyDescription = request.form['replyDescription']

        currentDT = datetime.datetime.now()

        replyDate = currentDT.strftime("%Y/%m/%d")

        replyTime = currentDT.strftime("%H:%M:%S")

        complainVO = ComplainVO()

        complainVO.complainId = complainId

        complainVO.replyDescription = replyDescription

        complainVO.replyDate = replyDate

        complainVO.replyTime = replyTime

        complainVO.complainStatus = "replied"

        complainDAO = ComplainDAO()

        complainDAO.adminReplyUserComplain(complainVO)

        return redirect(url_for('adminViewUserComplain'))

    else:

        return redirect(url_for('loadAdmin'))



