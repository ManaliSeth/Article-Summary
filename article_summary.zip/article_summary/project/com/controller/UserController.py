from project import app
from flask import render_template, request, session, redirect, url_for
from project.com.vo.UserVO import UserVO
from project.com.dao.UserDAO import UserDAO
from project.com.vo.LoginVO import LoginVO
from project.com.dao.LoginDAO import LoginDAO
import string
import random
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

@app.route('/userLoadLogin')
def userLoadLogin():
    return render_template('userSummary/login.html')


@app.route('/userLoadRegister')
def userLoadRegister():
    return render_template('userSummary/register.html')

@app.route('/userLoadContactUs')
def userLoadContactUs():
    return render_template('userSummary/ContactUs.html')


@app.route('/userLoadAboutUs')
def userLoadAboutUs():
    userDAO = UserDAO()
    userCountDict = userDAO.getUserCount()
    print(userCountDict)
    summaryCountDict = userDAO.getSummaryCount()
    print(summaryCountDict)
    return render_template('userSummary/aboutus.html', userCountDict=userCountDict, summaryCountDict=summaryCountDict)


@app.route('/userLoadLoginContactUs')
def userLoadLoginContactUs():
    return render_template('userSummary/loginContactUs.html')


@app.route('/userLoadLoginAboutUs')
def userLoadLoginAboutUs():
    userDAO = UserDAO()
    userCountDict = userDAO.getUserCount()
    print(userCountDict)
    summaryCountDict = userDAO.getSummaryCount()
    print(summaryCountDict)
    return render_template('userSummary/loginAboutUs.html', userCountDict=userCountDict, summaryCountDict=summaryCountDict)


@app.route('/userInsertUser', methods=['POST'])
def userInsertUser():
    loginVO = LoginVO()
    loginDAO = LoginDAO()

    userVO = UserVO()
    userDAO = UserDAO()

    userFirstName = request.form['userFirstName']
    userLastName = request.form['userLastName']
    loginEmail = request.form['loginEmail']
    userAddress = request.form['userAddress']
    userGender = request.form['userGender']
    userDateOfBirth = request.form['userDateOfBirth']
    userContactNumber = request.form['userContactNumber']
    loginPassword = request.form['loginPassword']
    # user_LoginId = session['loginId']
    # print(user_LoginId)

    # loginPassword = ''.join((random.choice(string.ascii_letters + string.digits)) for x in range(8))
    #
    # print("loginPassword=" + loginPassword)
    #
    # sender = "pythondemodonotreply@gmail.com"
    #
    # receiver = loginEmail
    #
    # msg = MIMEMultipart()
    #
    # msg['FROM'] = sender
    #
    # msg['TO'] = receiver
    #
    # msg['Subject'] = "PYTHON PASSWORD"
    #
    # msg.attach(MIMEText(loginPassword, 'plain'))
    #
    # server = smtplib.SMTP('smtp.gmail.com', 587)
    # server.ehlo()
    # server.starttls()
    # server.ehlo()
    # server.login(sender, "qazwsxedcrfvtgb1234567890!")
    #
    # text = msg.as_string()
    #
    # server.sendmail(sender, receiver, text)

    loginVO.loginEmail = loginEmail
    loginVO.loginPassword = loginPassword
    loginVO.loginRole = "user"
    loginVO.loginStatus = "active"

    loginDAO.insertLogin(loginVO)

    userVO.userFirstName = userFirstName
    userVO.userLastName = userLastName
    userVO.userAddress = userAddress
    userVO.userGender = userGender
    userVO.userDateOfBirth = userDateOfBirth
    userVO.userContactNumber = userContactNumber
    # userVO.userPassword = userPassword

    userDAO.insertUser(userVO)

    # server.quit()

    return render_template('userSummary/login.html')


@app.route('/userDeleteUser',methods=['GET'])
def userDeleteUser():
    if 'loginId' in session and session['loginRole'] == "user":

        loginId = session['loginId']

        print("loginId=", loginId)

        userVO = UserVO()

        userVO.loginId = loginId

        userDAO = UserDAO()

        userDAO.userDeleteUser(userVO)

        return render_template('userSummary/login.html')

    else:

        return redirect(url_for('loadUser'))


@app.route('/userEditUser',methods=['GET'])
def userEditUser():
    if 'loginId' in session and session['loginRole'] == "user":

        loginId = session['loginId']

        print("loginId=", loginId)

        userVO = UserVO()

        userVO.loginId = loginId

        userDAO = UserDAO()

        userDict = userDAO.userEditUser(userVO)

        return render_template('userSummary/editUser.html', userDict=userDict)
    else:

        return render_template('userSummary/login.html')


@app.route('/userUpdateUser', methods=['POST'])
def userUpdateUser():
    userId = request.form['userId']
    userFirstName = request.form['userFirstName']
    userLastName = request.form['userLastName']
    userAddress = request.form['userAddress']
    userGender = request.form['userGender']
    userDateOfBirth = request.form['userDateOfBirth']
    userContactNumber = request.form['userContactNumber']

    userVO = UserVO()

    userVO.userId = userId
    userVO.userFirstName = userFirstName
    userVO.userLastName = userLastName
    userVO.userAddress = userAddress
    userVO.userGender = userGender
    userVO.userDateOfBirth = userDateOfBirth
    userVO.userContactNumber = userContactNumber

    userDAO = UserDAO()

    userDAO.userUpdateUser(userVO)

    return redirect(url_for('loadUser'))



@app.route('/adminViewUser')
def adminViewUser():
    if 'loginId' in session and session['loginRole']=="admin":

        loginId = session['loginId']

        print("loginId=", loginId)

        userVO = UserVO()

        userVO.loginId = loginId

        userDAO = UserDAO()

        userDict = userDAO.adminViewUser()

        print(userDict)

        return render_template('adminSummary/viewUser.html', userDict=userDict)

    else:

        return render_template('userSummary/login.html')

@app.route('/adminBlockUser',methods=['GET'])
def adminBlockUser():

    userId = request.args.get('userId')

    userVO = UserVO()

    userVO.userId = userId

    userDAO = UserDAO()

    userDict = userDAO.getUserLoginId(userVO)

    print(userDict[0]['user_LoginId'])

    user_LoginId = userDict[0]['user_LoginId']

    userVO.user_LoginId = user_LoginId

    userDAO.adminBlockUser(userVO)

    return redirect(url_for('adminViewUser'))


# @app.route('/map')
# def map():
#     bloodbankAddress = request.args.get('bloodbankAddress')
#     return render_template('userSummary/Map.html',bloodbankAddress=bloodbankAddress)











