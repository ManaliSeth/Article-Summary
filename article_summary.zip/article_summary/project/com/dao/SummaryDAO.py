from project.com.dao import *

class SummaryDAO:

    def userAddSummary(self,summaryVO):
        connection = conn_db()
        cursor = connection.cursor()

        cursor.execute(
            "insert into SummaryMaster(summary_LoginId,datasetname,datasetpath,summaryDate,summary_articleType,summary_articleFormat,summary_datasetname,summary_datasetpath) values ('" + str(summaryVO.summary_LoginId) + "','" + summaryVO.datasetname + "','" + summaryVO.datasetpath + "','" + summaryVO.summaryDate + "','" + summaryVO.summary_articleType + "','" + summaryVO.summary_articleFormat+ "','" + summaryVO.summary_datasetname + "','" + summaryVO.summary_datasetpath + "')")
        connection.commit()
        cursor.close()
        connection.close()


    def userViewUserSummary(self,summaryVO):
        connection = conn_db()
        dict2=()
        cursor2 = connection.cursor()
        cursor2.execute("Select * from SummaryMaster S where summary_LoginId = '" + str(summaryVO.summary_LoginId) + "' ")
        dict2 = cursor2.fetchall()
        cursor2.close()
        connection.close()
        return dict2


    def adminViewUserSummary(self):
        connection = conn_db()
        dict1 = ()
        cursor = connection.cursor()
        cursor.execute("select * from LoginMaster L inner join SummaryMaster S where L.loginId= S.summary_LoginId")
        dict1 = cursor.fetchall()
        cursor.close()
        connection.close()
        return dict1


