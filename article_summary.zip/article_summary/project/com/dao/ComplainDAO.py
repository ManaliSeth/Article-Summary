from project.com.dao import *


class ComplainDAO:

    def userAddComplain(self,complainVO):
        connection = conn_db()
        cursor = connection.cursor()

        cursor.execute(
            "insert into ComplainMaster(complainSubject,complainDescription,datasetname,datasetpath,complainFrom_LoginId,complainDate,complainStatus) values ('" + complainVO.complainSubject + "','" + complainVO.complainDescription + "','" + complainVO.datasetname + "','" + complainVO.datasetpath + "','" + str(complainVO.complainFrom_LoginId) + "','" + complainVO.complainDate + "','" + complainVO.complainStatus + "')")
        connection.commit()
        cursor.close()
        connection.close()

    def userViewUserComplain(self,complainVO):
        connection = conn_db()
        cursor2 = connection.cursor()
        cursor2.execute("Select * from ComplainMaster C inner join LoginMaster L where L.loginId = C.complainFrom_LoginId and C.complainFrom_LoginId ='"+str(complainVO.complainFrom_LoginId)+"'  ")
        dict2 = cursor2.fetchall()
        cursor2.close()
        connection.close()
        return dict2

    def getLoginEmail(self,complainVO):
        connection = conn_db()
        cursor = connection.cursor()
        cursor.execute("select DISTINCT(loginEmail),complainFrom_LoginId from   ComplainMaster C inner join LoginMaster L where C.complainFrom_LoginId = L.loginID and C.complainFrom_LoginId = '"+str(complainVO.complainFrom_LoginId)+"'")
        dict1 = cursor.fetchall()
        connection.commit()
        cursor.close()
        connection.close()
        return dict1


    def getUserComplaintDetails(self,complainVO):
        connection = conn_db()
        cursor = connection.cursor()
        cursor.execute("select * from ComplainMaster where complainId = '"+str(complainVO.complainId)+"'")
        dict1 = cursor.fetchall()
        connection.commit()
        cursor.close()
        connection.close()
        return dict1


    def adminViewUserComplain(self):
        connection = conn_db()
        cursor = connection.cursor()
        cursor.execute("Select * from ComplainMaster C inner join LoginMaster L where L.loginId = C.complainFrom_LoginId and L.loginRole = 'user'")
        dict1 = cursor.fetchall()
        connection.commit()
        cursor.close()
        connection.close()
        return dict1

    def adminReplyUserComplain(self,complainVO):
        connection = conn_db()
        cursor = connection.cursor()
        cursor.execute("update ComplainMaster set complainStatus = '"+complainVO.complainStatus+"', replyDescription ='"+complainVO.replyDescription+"' ,replyDate = '"+complainVO.replyDate+"' where complainId = '"+str(complainVO.complainId)+"' ")
        connection.commit()
        cursor.close()
        connection.close()
