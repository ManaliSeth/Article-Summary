from project.com.dao import *

class FeedbackDAO:

    def userAddFeedback(self,feedbackVO):
        connection = conn_db()
        cursor = connection.cursor()

        cursor.execute(
            "insert into FeedbackMaster(feedbackRating,feedbackDescription,feedbackFrom_LoginId,feedbackDate) values ('" + feedbackVO.feedbackRating + "','" + feedbackVO.feedbackDescription + "','" + str(feedbackVO.feedbackFrom_LoginId) + "','" + feedbackVO.feedbackDate + "'")
        connection.commit()
        cursor.close()
        connection.close()


    def userViewUserFeedback(self,feedbackVO):
        connection = conn_db()
        cursor = connection.cursor()
        cursor.execute("select * from FeedbackMaster where feedbackFrom_LoginId = '"+str(feedbackVO.feedbackFrom_LoginId)+"'")
        dict1= cursor.fetchall()
        connection.commit()
        cursor.close()
        connection.close()
        return dict1


    def adminViewUserFeedback(self,feedbackVO):
        connection = conn_db()
        cursor = connection.cursor()
        cursor.execute("Select * from FeedbackMaster F inner join LoginMaster L where L.loginId = F.feedbackFrom_LoginId and L.loginRole = 'user'")
        dict1 = cursor.fetchall()
        cursor.close()
        connection.close()
        return dict1