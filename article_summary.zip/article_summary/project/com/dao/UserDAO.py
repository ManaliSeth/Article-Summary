from project.com.dao import conn_db


class UserDAO:

    def insertUser(self, userVO):
        connection = conn_db()
        cursor = connection.cursor()
        cursor2 = connection.cursor()
        cursor.execute("Select max(loginId) as loginId from LoginMaster")
        dict1 = cursor.fetchone()
        print(dict1)
        userVO.user_LoginId = str(dict1['loginId'])
        cursor.execute(
            "insert into UserMaster(userFirstName,userLastName,userAddress,userGender,userDateOfBirth,userContactNumber,user_LoginId) values ('" + userVO.userFirstName + "','" + userVO.userLastName + "','" + userVO.userAddress + "','" + userVO.userGender + "','" + userVO.userDateOfBirth + "','" + userVO.userContactNumber + "','" + userVO.user_LoginId + "')")
        # cursor2.execute("insert into details(firstname,lastname,password) values ('"+userVO.userFirstName+"','"+userVO.userLastName+"','"+userVO.userPassword+"')")
        connection.commit()
        cursor.close()
        connection.close()


    def userDeleteUser(self,userVO):
        connection = conn_db()
        cursor = connection.cursor()
        cursor.execute("update LoginMaster set loginStatus='deactive' where loginId = '"+userVO.loginId+"'")
        connection.commit()
        cursor.close()
        connection.close()


    def userEditUser(self, userVO):
        connection = conn_db()
        cursor1 = connection.cursor()
        cursor1.execute(
                    "Select * from UserMaster where user_LoginId = '"+str(userVO.loginId)+"'")
        dict1 = cursor1.fetchall()
        cursor1.close()
        connection.close()
        return dict1


    def userUpdateUser(self, userVO):
        connection = conn_db()
        cursor = connection.cursor()

        cursor.execute(
            "update UserMaster set userFirstName ='{}',userLastName = '{}',userAddress = '{}', userGender = '{}',userDateOfBirth = '{}',userContactNumber = '{}' where userId = '{}'".format(
                userVO.userFirstName, userVO.userLastName,userVO.userAddress,
                userVO.userGender, userVO.userDateOfBirth, userVO.userContactNumber,
                userVO.userId))
        connection.commit()
        cursor.close()
        connection.close()



    def adminViewUser(self):
        connection = conn_db()
        cursor = connection.cursor()
        cursor.execute("Select * from UserMaster U inner join LoginMaster L where L.loginId = U.user_LoginId and loginStatus = 'active' ")
        dict1 = cursor.fetchall()
        cursor.close()
        connection.close()
        return dict1

    def getUserLoginId(self, userVO):
        connection = conn_db()
        cursor = connection.cursor()
        cursor.execute("select user_LoginId from UserMaster where userId = '{}'".format(userVO.userId))
        dict1 = cursor.fetchall()
        connection.commit()
        cursor.close()
        connection.close()
        return dict1


    def adminBlockUser(self, userVO):
        connection = conn_db()
        cursor = connection.cursor()
        cursor.execute("update LoginMaster set loginStatus = 'deactive' where loginId = '{}'".format(userVO.user_LoginId))
        connection.commit()
        cursor.close()
        connection.close()


    def getUserCount(self):
        connection = conn_db()
        cursor = connection.cursor()
        cursor.execute(
            "SELECT COUNT(userId) AS users FROM userMaster")
        dict1 = cursor.fetchall()
        connection.commit()
        cursor.close()
        connection.close()
        return dict1


    def getSummaryCount(self):
        connection = conn_db()
        cursor = connection.cursor()
        cursor.execute(
            "SELECT COUNT(summaryId) AS summaries FROM summaryMaster")
        dict1 = cursor.fetchall()
        connection.commit()
        cursor.close()
        connection.close()
        return dict1