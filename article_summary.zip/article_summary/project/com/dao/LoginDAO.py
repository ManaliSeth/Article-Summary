from project.com.dao import *

class LoginDAO:

    def insertLogin(self,loginVO):

        connection = conn_db()
        cursor = connection.cursor()

        cursor.execute("insert into LoginMaster(loginEmail,loginPassword,loginRole,loginStatus) values('"+loginVO.loginEmail+"','"+loginVO.loginPassword+"','"+loginVO.loginRole+"','"+loginVO.loginStatus+"')")
        loginDict = cursor.fetchall()
        connection.commit()
        cursor.close()
        connection.close()
        return loginDict

    def searchLogin(self,loginVO):
        connection = conn_db()
        cursor = connection.cursor()

        cursor.execute(
            "select * from LoginMaster where loginEmail = '"+loginVO.loginEmail+"' and loginPassword = '"+loginVO.loginPassword+"' and loginStatus ='active' ")
        loginDict = cursor.fetchall()
        connection.commit()
        cursor.close()
        connection.close()
        return loginDict


    def checkLoginEmail(self,loginVO):
        connection = conn_db()
        cursor = connection.cursor()

        cursor.execute(
            "select loginEmail from LoginMaster where loginEmail = '" + loginVO.loginEmail + "' ")
        loginDict = cursor.fetchall()
        connection.commit()
        cursor.close()
        connection.close()
        return loginDict

    def updatePassword(self,loginVO):
        connection = conn_db()
        cursor = connection.cursor()

        cursor.execute(
            "update LoginMaster set loginPassword = '"+loginVO.loginPassword+"' where loginEmail = '" + loginVO.loginEmail + "' ")

        connection.commit()
        cursor.close()
        connection.close()

    def getCurrentPassword(self,loginVO):
        connection = conn_db()
        cursor = connection.cursor()

        cursor.execute(
            "select loginPassword from LoginMaster where loginId = '" + str(loginVO.loginId) + "' and loginPassword = '"+loginVO.oldPassword+"'")

        dict1 = cursor.fetchall()
        connection.commit()
        cursor.close()
        connection.close()
        return dict1

    def setNewPassword(self,loginVO):
        connection = conn_db()
        cursor = connection.cursor()

        cursor.execute(
            "update LoginMaster set loginPassword = '"+loginVO.newPassword+"' where loginId = '" + str(loginVO.loginId) + "' ")

        dict1 = cursor.fetchall()
        connection.commit()
        cursor.close()
        connection.close()
        return dict1

    def getSummaryCount(self):
        connection = conn_db()
        cursor = connection.cursor()
        cursor.execute(
            "SELECT COUNT(summaryId)AS summarycount,userFirstName AS username FROM summaryMaster s1 INNER JOIN UserMaster u1 WHERE s1.`summary_LoginId`=u1.user_LoginId AND user_LoginId IN (SELECT user_LoginId FROM UserMaster u INNER JOIN LoginMaster a WHERE  u.user_LoginId = a.loginId) GROUP BY u1.userFirstName")
        dict = cursor.fetchall()
        connection.commit()
        cursor.close()
        connection.close()
        return dict

    def getUserCount(self):
        connection = conn_db()
        cursor = connection.cursor()
        cursor.execute("SELECT COUNT(DISTINCT(user_LoginId)) AS usercount FROM usermaster u INNER JOIN loginmaster l WHERE u.`user_LoginId`=l.`loginId` AND l.loginStatus='active';")
        dict = cursor.fetchall()
        connection.commit()
        cursor.close()
        connection.close()
        return dict

    def getUserSummaryCount(self):
        connection = conn_db()
        cursor = connection.cursor()
        cursor.execute(
            "SELECT COUNT(summaryId) AS usersummary FROM summarymaster S INNER JOIN loginmaster L WHERE s.`summary_LoginId` = l.`loginId` AND loginRole = 'user'")
        dict = cursor.fetchall()
        connection.commit()
        cursor.close()
        connection.close()
        return dict

    def getUserComplainCount(self):
        connection = conn_db()
        cursor = connection.cursor()
        cursor.execute(
            "SELECT COUNT(complainId) AS usercomplain FROM complainmaster C INNER JOIN loginmaster L WHERE c.`complainFrom_LoginId` = l.`loginId` AND loginRole = 'user'")
        dict = cursor.fetchall()
        connection.commit()
        cursor.close()
        connection.close()
        return dict

    def getUserFeedbackCount(self):
        connection = conn_db()
        cursor = connection.cursor()
        cursor.execute(
            "SELECT COUNT(feedbackId) AS userfeedback FROM feedbackmaster F INNER JOIN loginmaster L WHERE f.`feedbackFrom_LoginId` = l.`loginId` AND loginRole = 'user'")
        dict = cursor.fetchall()
        connection.commit()
        cursor.close()
        connection.close()
        return dict










