from wtforms import *

class SummaryVO:
    summaryId = IntegerField
    summary_UserId = IntegerField
    datasetname = StringField
    datasetpath = StringField
    # summaryFrom_LoginId = IntegerField
    summaryDate = StringField
    summary_articleType = StringField
    summary_articleFormat = StringField
    summary_datasetname = StringField
    summary_datasetpath = StringField